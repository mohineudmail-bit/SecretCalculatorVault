package com.example.secretcalculatorvault

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.io.File

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags( android.view.WindowManager.LayoutParams.FLAG_SECURE,
            android.view.WindowManager.LayoutParams.FLAG_SECURE )
        setContent { MaterialTheme { VaultApp(this) } }
    }
}

@Composable
private fun VaultApp(activity: FragmentActivity) {
    val context = LocalContext.current
    val store = remember { VaultStore(context) }
    val prefs = remember { context.getSharedPreferences("vault_setup", 0) }
    var pin by remember { mutableStateOf("") }
    var savedPin by remember { mutableStateOf(prefs.getString("pin", null)) }
    var unlocked by remember { mutableStateOf(false) }
    var setupMode by remember { mutableStateOf(savedPin == null) }
    var section by remember { mutableStateOf("personal") }
    var refresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val name = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val index = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && index >= 0) c.getString(index) else "private_file"
                } ?: "private_file"
                val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                store.import(uri, name, mime, section)
                refresh++
                message = "Encrypted file added to $section vault"
            } catch (e: Exception) { message = "Import failed: ${e.message}" }
        }
    }

    if (!unlocked) {
        CalculatorScreen(
            pin = pin,
            onDigit = { if (pin.length < 12) pin += it },
            onClear = { pin = "" },
            onEquals = {
                if (setupMode) {
                    if (pin.length >= 4) {
                        prefs.edit().putString("pin", pin).apply()
                        savedPin = pin
                        setupMode = false
                        unlocked = true
                        pin = ""
                    } else message = "Choose a PIN with at least 4 digits"
                } else {
                    if (pin == savedPin) unlocked = true
                    else message = "Incorrect PIN"
                    pin = ""
                }
            },
            title = if (setupMode) "Set your secret PIN, then press =" else "Enter PIN, then press =",
            message = message
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Private Vault", fontWeight = FontWeight.Bold) },
                actions = { IconButton(onClick = { unlocked = false; pin = "" }) {
                    Icon(Icons.Default.Lock, contentDescription = "Lock vault")
                } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                Icon(Icons.Default.Add, contentDescription = "Import file")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("Your encrypted space", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = section == "personal", onClick = { section = "personal"; refresh++ }, label = { Text("Personal") })
                FilterChip(selected = section == "work", onClick = { section = "work"; refresh++ }, label = { Text("Workspace") })
            }
            Text(
                if (section == "work") "Separate in-app workspace. This is not an Android Enterprise managed profile."
                else "Files are encrypted in this app's private storage.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.height(12.dp))
            val entries = remember(refresh, section) { store.items(section) }
            if (entries.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOff, null, modifier = Modifier.size(44.dp))
                        Text("No private files yet")
                        Text("Tap + to import photos, videos or documents", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries, key = { it.id }) { item ->
                        Card {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (item.mime.startsWith("video")) Icons.Default.Movie else Icons.Default.InsertDriveFile, null)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.Medium)
                                    Text(item.mime, style = MaterialTheme.typography.labelSmall)
                                }
                                IconButton(onClick = {
                                    try {
                                        val bytes = store.read(item)
                                        val out = File(context.cacheDir, item.name.replace("/", "_"))
                                        out.writeBytes(bytes)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(
                                            context, context.packageName + ".fileprovider", out
                                        )
                                        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        context.startActivity(intent)
                                    } catch (e: Exception) { message = "Cannot open file: ${e.message}" }
                                }) { Icon(Icons.Default.OpenInNew, contentDescription = "Open") }
                                IconButton(onClick = { store.delete(item); refresh++ }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { showBiometric(activity) { message = "Biometric verified" } }) {
                Icon(Icons.Default.Fingerprint, null)
                Spacer(Modifier.width(8.dp))
                Text("Test biometric authentication")
            }
        }
    }
}

private fun showBiometric(activity: FragmentActivity, onSuccess: () -> Unit) {
    val manager = BiometricManager.from(activity)
    if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) return
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
        })
    prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
        .setTitle("Verify identity")
        .setSubtitle("Authenticate to continue")
        .setNegativeButtonText("Cancel")
        .build())
}

@Composable
private fun CalculatorScreen(
    pin: String, onDigit: (String) -> Unit, onClear: () -> Unit,
    onEquals: () -> Unit, title: String, message: String
) {
    var display by remember { mutableStateOf("0") }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(20.dp),
        verticalArrangement = Arrangement.Bottom) {
        Text("Calculator", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(24.dp))
        Text(if (pin.isEmpty()) display else "•".repeat(pin.length),
            modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.displayMedium)
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(18.dp))
        val keys = listOf("7","8","9","÷","4","5","6","×","1","2","3","−","C","0","=","+")
        keys.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { key ->
                    FilledTonalButton(
                        onClick = {
                            when (key) {
                                "C" -> { onClear(); display = "0" }
                                "=" -> onEquals()
                                in listOf("÷","×","−","+") -> { /* keypad operator remains calculator-style */ }
                                else -> { onDigit(key); display = if (display == "0") key else display + key }
                            }
                        },
                        modifier = Modifier.weight(1f).height(68.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text(key, style = MaterialTheme.typography.titleLarge) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}
