package com.example.secretcalculatorvault

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class VaultItem(val id: String, val name: String, val mime: String, val area: String)

class VaultStore(private val context: Context) {
    private val base = File(context.filesDir, "vault").apply { mkdirs() }
    private val indexFile = File(base, "index.json")

    private fun readIndex(): JSONArray = try {
        if (indexFile.exists()) JSONArray(indexFile.readText()) else JSONArray()
    } catch (_: Exception) { JSONArray() }

    private fun writeIndex(array: JSONArray) {
        val temp = File(base, "index.tmp")
        temp.writeText(array.toString())
        if (!temp.renameTo(indexFile)) {
            indexFile.writeText(array.toString())
            temp.delete()
        }
    }

    fun items(area: String): List<VaultItem> {
        val a = readIndex()
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            if (o.optString("area") == area) VaultItem(
                o.optString("id"), o.optString("name"),
                o.optString("mime"), o.optString("area")
            ) else null
        }
    }

    fun import(contextUri: Uri, name: String, mime: String, area: String) {
        val bytes = context.contentResolver.openInputStream(contextUri)?.use { it.readBytes() }
            ?: error("Cannot read selected file")
        val id = MessageDigest.getInstance("SHA-256")
            .digest((System.nanoTime().toString() + name).toByteArray())
            .take(12).joinToString("") { "%02x".format(it) }
        File(base, "$id.bin").writeBytes(VaultCrypto.encrypt(bytes))
        val index = readIndex()
        index.put(JSONObject().put("id", id).put("name", name)
            .put("mime", mime.ifBlank { "application/octet-stream" }).put("area", area))
        writeIndex(index)
    }

    fun read(item: VaultItem): ByteArray =
        VaultCrypto.decrypt(File(base, "${item.id}.bin").readBytes())

    fun delete(item: VaultItem) {
        File(base, "${item.id}.bin").delete()
        val old = readIndex()
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("id") != item.id) next.put(o)
        }
        writeIndex(next)
    }
}
